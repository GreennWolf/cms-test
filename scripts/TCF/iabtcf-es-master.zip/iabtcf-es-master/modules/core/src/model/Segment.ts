export enum Segment {

  CORE = 'core',
  VENDORS_DISCLOSED= 'vendorsDisclosed',
  VENDORS_ALLOWED= 'vendorsAllowed',
  PUBLISHER_TC= 'publisherTC',

}
