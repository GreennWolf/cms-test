import {IntMap} from '../IntMap.js';
export type IDSetMap = IntMap<Set<number>>
