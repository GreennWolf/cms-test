import {GVLMapItem} from './GVLMapItem.js';

export interface DataCategory extends GVLMapItem {
  description: string;
}
