export interface VendorUrl {
    langId: string;
    privacy: string;
    legIntClaim: string;
}
