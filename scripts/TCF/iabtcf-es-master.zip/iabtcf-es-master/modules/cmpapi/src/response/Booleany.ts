export type Booleany = boolean | 1 | 0;
