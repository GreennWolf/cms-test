export interface BooleanVector {
  [id: string]: boolean;
}
