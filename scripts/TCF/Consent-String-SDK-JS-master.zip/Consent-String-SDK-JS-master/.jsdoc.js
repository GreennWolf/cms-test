module.exports = {
  source: {
    include: [
      'README.md',
      'src/consent-string.js',
    ],
  },
  opts: {
    destination: 'docs/',
  },
};
