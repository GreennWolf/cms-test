export enum DeviceDisclosureStorageAccessType {
  COOKIE = 'cookie',
  WEB = 'web',
  APP = 'app'
}
