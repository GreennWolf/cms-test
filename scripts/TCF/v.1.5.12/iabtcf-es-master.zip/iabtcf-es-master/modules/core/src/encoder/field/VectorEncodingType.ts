export enum VectorEncodingType {
  FIELD = 0,
  RANGE = 1
}
