export interface GVLMapItem {
  id: number;
  name: string;
}
