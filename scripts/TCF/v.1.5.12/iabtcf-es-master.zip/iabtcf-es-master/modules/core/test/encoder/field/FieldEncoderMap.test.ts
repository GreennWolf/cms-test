// import {FieldEncoderMap} from '../../../src/encoder/field/FieldEncoderMap';
import {expect} from 'chai';

describe('encoder/field->FieldEncoderMap', (): void => {

  it('\x1b[36mNeeds Unit Tests\x1b[0m', (done: () => void): void => {

    expect(true).to.be.true;
    done();

  });

});
