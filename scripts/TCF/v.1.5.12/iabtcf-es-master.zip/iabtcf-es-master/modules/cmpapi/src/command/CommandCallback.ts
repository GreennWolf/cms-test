export type CommandCallback = (...params) => void;
