<?php

session_start();

if (!$_SESSION['smtp']['mail']  || !$_SESSION['smtp']['Message']) {
	
	exit();
	
}


?>

<!--script>window.parent.document.getElementById('bbSubmit').value="Enviando... Espere...";</script-->

<?php

$_REQUEST['Message'] = '
Sistema de información

	Control de denuncias
			
			'.$_SESSION['smtp']['Message'].'
			
			
			
';


$_REQUEST['Subject'] = $_SESSION['smtp']['Subject'];


/*
$_REQUEST['Subject'] = $_REQUEST['Subject'].' - Contacto En Linea - aquiTODO admins';
*/





// example on using PHPMailer with GMAIL
if(function_exists('date_default_timezone_set')) {
	date_default_timezone_set('Europe/Madrid');
}

include("class.phpmailer.php");
include("class.smtp.php"); // note, this is optional - gets called from main class if not already loaded

$mail             = new PHPMailer();



$mail->IsSMTP();
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
$mail->Host       = "smtp.sistemadeinformacion.es";      // sets GMAIL as the SMTP server
$mail->Port       = 465;                   // set the SMTP port
//$mail->Port       = 587;

//$mail->IsSendmail();  // tell the class to use Sendmail

$mailPass = array();
$mailpass[] = array ('u'=>'denuncias@sistemadeinformacion.es','p'=>'v#T2b0t84');


$rdn = rand(0,sizeof($mailpass)-1);
$mail_mail = $mailpass[$rdn]['u'];
$mail_pass = $mailpass[$rdn]['p'];



$mail->Username   = $mail_mail;  // GMAIL username
$mail->Password   = $mail_pass;  // GMAIL password



$mail->From       = "Sistema de denuncias";
$mail->FromName   = "Denuncias";
$mail->Subject    = "Sistema de denuncias";
$mail->WordWrap   = 50; // set word wrap

$body .= $_REQUEST['Message'];

//$mail->Body    = $body;
$mail->MsgHTML($body);

//$mail->AddReplyTo("world.sport.mollet@gmail.com","World Sport Mollet"); // Direcci�n de Respuesta
//$mail->AddAttachment("foto.jpg", "foto.jpg");

//$mail->AddAttachment("foto.jpg", "foto.jpg");


/*
$Formulari = 'formRecepMail.'.date('YMD');
include('newReceptaPDF.php');
$mail->AddAttachment($url, $Formulari.'.pdf');
*/

//$mail->AddAddress($_REQUEST['eMail'] ,$_REQUEST['name'] );

if ($_SESSION['smtp']['copy']) {
	$mail->AddBCC($_SESSION['smtp']['copy'], 'Empresa');
}

function mailSendedOk() {
	
	/*
	?>
		Todos Los Mensajes Enviados
		<script>window.parent.document.getElementById('Formulario').innerHTML = '<h3 style="color:green;">Mensaje <b>enviado</b>!</h3>'+window.parent.document.getElementById('Formulario').innerHTML;</script>

		<script>window.parent.document.location.href=window.parent.document.location.href+"#formulario";</script>

		<script>window.parent.document.getElementById('formSend').clear();</script>
		<script>window.parent.document.getElementById('bbSubmit').value="Enviar Otro >";</script>
		<script>window.parent.document.getElementById('bbSubmit').disabled="";</script>
	<?php
	*/
	$_SESSION['smtp'] = false;
}

function mailFailed() {
	
	/*
	?>
		<script>window.parent.document.getElementById('Formulario').innerHTML = '<h3 style="color:red;">Mensaje <b>FALLIDO</b>!</h3>'+window.parent.document.getElementById('Formulario').innerHTML;</script>

		<script>window.parent.document.location.href=window.parent.document.location.href+"#formulario";</script>

		<!--script>window.parent.document.getElementById('formSend').clear();</script-->
		<script>window.parent.document.getElementById('bbSubmit').value="Reintentar >";</script>
		<script>window.parent.document.getElementById('bbSubmit').disabled="";</script>
	<?php
	
	*/
}


//$mail_debug = 1;
$mail_debug = false;

if ($email=$_SESSION['smtp']['mail']) {

	if($mail_debug) echo debug('MAIL: '.$email,$HTML=true);

	$mail->AddAddress($email,ucfirst($name));
	if($r = $mail->Send()) {

		
		@mailSendedOk();

	}
	else {
		$cabeceras = 'From: ' . $mail_mail . "\r\n" .
		'Reply-To: ' . $mail_mail . "\r\n".
		'BCC: ' . $_SESSION['smtp']['copy'] . "\r\n";
		
		if ($mmm = @mail($to=$email,$subject=$_REQUEST['Subject'],$message=$_REQUEST['Message'],$cabeceras)) {
			@mailSendedOk();
		}
		else {
                        
			include('indexMailerAjax.php');
			@mailFailed();
		}
		
	}
}
else {
	if($mail_debug) echo debug('NOT FOUND ANY MAIL',$HTML=true);
	@mailFailed();
}


?>