# ASM GDPR Cookie Consent Script
Free script to insert a "Free and Open Source GDPR Cookie Consent Script" on your site:

More info and configuration on https://algosemueve.es/en/something-about-it/asm-cookie-consent-advice-script

By ciro Artigot 
